// NOVA Global Intelligence V2 - built-in Node.js server (no npm packages required)
const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '0.0.0.0';
const DATA_DIR = path.join(__dirname, 'nova-data');
const TASKS_FILE = path.join(DATA_DIR, 'tasks.json');
const INCOME_FILE = path.join(DATA_DIR, 'income.json');
const LESSONS_FILE = path.join(DATA_DIR, 'lessons.json');
const UPGRADES_FILE = path.join(DATA_DIR, 'upgrades.json');
fs.mkdirSync(DATA_DIR, { recursive: true });

function readJson(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; }
}
function writeJson(file, value) { fs.writeFileSync(file, JSON.stringify(value, null, 2), { mode: 0o600 }); }
function send(res, status, data, type='application/json; charset=utf-8') {
  res.writeHead(status, {'Content-Type': type, 'Cache-Control':'no-store', 'X-Content-Type-Options':'nosniff'});
  res.end(type.startsWith('application/json') ? JSON.stringify(data) : data);
}
function body(req) {
  return new Promise((resolve, reject) => {
    let raw = ''; req.on('data', c => { raw += c; if (raw.length > 1e6) req.destroy(); });
    req.on('end', () => { try { resolve(raw ? JSON.parse(raw) : {}); } catch { reject(new Error('Invalid JSON')); } });
    req.on('error', reject);
  });
}
const tasks = () => readJson(TASKS_FILE, []);
const income = () => readJson(INCOME_FILE, {total:0, entries:[]});
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  try {
    if (req.method === 'GET' && ['/', '/index.html', '/manifest.json', '/sw.js'].includes(url.pathname)) {
      const name = url.pathname === '/' ? 'index.html' : url.pathname.slice(1);
      const file = path.join(__dirname, name);
      if (!fs.existsSync(file)) return send(res,404,{error:name+' not found'});
      const types = {'index.html':'text/html; charset=utf-8','manifest.json':'application/manifest+json; charset=utf-8','sw.js':'text/javascript; charset=utf-8'};
      return send(res,200,fs.readFileSync(file),types[name]);
    }
    if (req.method === 'GET' && url.pathname === '/api/health') {
      return send(res,200,{status:'ok',service:'NOVA Global Intelligence',backend:true,aiConfigured:Boolean(process.env.OPENAI_API_KEY),model:process.env.OPENAI_MODEL || 'gpt-5.6'});
    }
    if (req.method === 'GET' && url.pathname === '/api/tasks') return send(res,200,{tasks:tasks()});
    if (req.method === 'POST' && url.pathname === '/api/tasks') {
      const t = await body(req);
      if (!t.title || typeof t.title !== 'string') return send(res,400,{error:'Task title required'});
      const all = tasks(); const id = String(t.id || `t_${Date.now()}`);
      const item = {id,title:t.title.slice(0,500),done:Boolean(t.done),createdAt:t.createdAt || new Date().toISOString()};
      const filtered = all.filter(x => x.id !== id); filtered.unshift(item); writeJson(TASKS_FILE,filtered);
      return send(res,201,{task:item});
    }
    if ((req.method === 'PATCH' || req.method === 'DELETE') && url.pathname.startsWith('/api/tasks/')) {
      const id = decodeURIComponent(url.pathname.slice('/api/tasks/'.length));
      let all = tasks();
      if (req.method === 'DELETE') { all=all.filter(x=>x.id!==id); writeJson(TASKS_FILE,all); return send(res,200,{ok:true}); }
      const patch=await body(req); let found=false;
      all=all.map(t=>{if(t.id===id){found=true;return {...t,done:Boolean(patch.done)}}return t});
      if(!found)return send(res,404,{error:'Task not found'});writeJson(TASKS_FILE,all);return send(res,200,{ok:true});
    }

    if (req.method === 'GET' && url.pathname === '/api/lessons') return send(res,200,{lessons:readJson(LESSONS_FILE,[])});
    if (req.method === 'POST' && url.pathname === '/api/lessons') {
      const p=await body(req);
      if(typeof p.what!=='string'||!p.what.trim()||typeof p.result!=='string'||!p.result.trim()) return send(res,400,{error:'Both what and result are required'});
      const a=readJson(LESSONS_FILE,[]); const item={id:`l_${Date.now()}`,what:p.what.slice(0,500),result:p.result.slice(0,3000),createdAt:new Date().toISOString()};
      a.unshift(item);writeJson(LESSONS_FILE,a.slice(0,500));return send(res,201,{lesson:item});
    }
    if (req.method === 'GET' && url.pathname === '/api/upgrades') return send(res,200,{upgrades:readJson(UPGRADES_FILE,[])});
    if (req.method === 'POST' && url.pathname === '/api/upgrades') {
      const p=await body(req);
      if(typeof p.title!=='string'||!p.title.trim()) return send(res,400,{error:'Upgrade title required'});
      const a=readJson(UPGRADES_FILE,[]);const item={id:`u_${Date.now()}`,title:p.title.slice(0,500),reason:String(p.reason||'').slice(0,3000),status:'Proposed',createdAt:new Date().toISOString()};
      a.unshift(item);writeJson(UPGRADES_FILE,a.slice(0,500));return send(res,201,{upgrade:item});
    }
    if (req.method === 'PATCH' && url.pathname.startsWith('/api/upgrades/')) {
      const id=decodeURIComponent(url.pathname.slice('/api/upgrades/'.length));const p=await body(req);const a=readJson(UPGRADES_FILE,[]);let found=false;
      const next=a.map(x=>{if(x.id===id){found=true;return {...x,status:String(p.status||x.status).slice(0,40),updatedAt:new Date().toISOString()}}return x});
      if(!found)return send(res,404,{error:'Upgrade not found'});writeJson(UPGRADES_FILE,next);return send(res,200,{ok:true,upgrades:next});
    }

    if (req.method === 'GET' && url.pathname === '/api/income') return send(res,200,income());
    if (req.method === 'POST' && url.pathname === '/api/income') {
      const p=await body(req); const amount=Number(p.amount);
      if(p.confirmed!==true || !Number.isFinite(amount) || amount<=0 || amount>1e9) return send(res,400,{error:'Only manually confirmed real payments can be recorded'});
      const data=income();data.total=Math.round((data.total+amount)*100)/100;
      data.entries.push({amount,confirmed:true,recordedAt:new Date().toISOString()});writeJson(INCOME_FILE,data);return send(res,201,data);
    }
    if (req.method === 'POST' && url.pathname === '/api/chat') {
      const input=await body(req);
      if(!input.message || typeof input.message!=='string') return send(res,400,{error:'Message required'});
      const key=process.env.OPENAI_API_KEY;
      if(!key) return send(res,503,{error:'AI backend is online, but OPENAI_API_KEY is not configured. Set the key securely in the hosting environment.'});
      const system = `You are NOVA Global Intelligence, the user's practical personal AI assistant. Use warm, respectful Hindi/Hinglish when suitable. Help with research plans, business ideas, coding, task planning, personal goals, structured reasoning, self-critique, and improvement proposals. Prioritize the owner's stated goal, low/no-cost experiments, clear Hindi/Hinglish when useful, and one next action at a time. Use a loop: clarify objective, list assumptions, make a plan, check risks, define a measurable test, and review results when supplied. Never claim to learn persistently unless the user has saved a lesson; never claim to edit or deploy your own code. Be honest about uncertainty; never promise guaranteed income. Do not claim to have performed live web research unless a connected tool actually did so. Prioritize zero-cost lawful options. Do not initiate purchases, payments, account creation, contracts, or send messages; prepare drafts and ask the user to approve external actions. Do not expose API keys or secrets. User-selected mode: ${String(input.mode||'general').slice(0,50)}. User goal: ${String(input.goal||'not specified').slice(0,1000)}. Response style: ${String(input.style||'simple').slice(0,100)}.`;
      try {
        const r=await fetch('https://api.openai.com/v1/responses',{method:'POST',headers:{'Authorization':`Bearer ${key}`,'Content-Type':'application/json'},body:JSON.stringify({model:process.env.OPENAI_MODEL||'gpt-5.6',instructions:system,input:input.message,max_output_tokens:1200})});
        const data=await r.json();
        if(!r.ok)return send(res,502,{error:data.error?.message||`AI provider returned HTTP ${r.status}`});
        let reply=data.output_text;
        if(!reply && Array.isArray(data.output)) reply=data.output.flatMap(o=>o.content||[]).filter(c=>c.type==='output_text').map(c=>c.text).join('\\n');
        return send(res,200,{reply:reply||'The AI returned no text.',provider:'OpenAI',model:process.env.OPENAI_MODEL||'gpt-5.6'});
      } catch(e) { return send(res,502,{error:'Could not reach AI provider. Check server internet and provider configuration.'}); }
    }
    return send(res,404,{error:'Not found'});
  } catch(e) { return send(res,400,{error:e.message || 'Bad request'}); }
});
server.listen(PORT,HOST,()=>console.log(`NOVA Global Intelligence listening on ${HOST}:${PORT}; AI key configured: ${Boolean(process.env.OPENAI_API_KEY)}`));
