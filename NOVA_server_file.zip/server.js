const http = require("http");
const fs = require("fs");
const path = require("path");

const PORT = Number(process.env.PORT || 3001);
const HOST = "0.0.0.0";
const KEY = process.env.OPENAI_API_KEY || "";
const MODEL = process.env.OPENAI_MODEL || "gpt-4.1-mini";
const ROOT = path.resolve(__dirname);

const types = {
  ".html": "text/html; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".svg": "image/svg+xml",
  ".webp": "image/webp",
  ".ico": "image/x-icon",
  ".webmanifest": "application/manifest+json"
};

function send(res, status, data, type = "application/json; charset=utf-8") {
  res.writeHead(status, {
    "Content-Type": type,
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, HEAD, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Cache-Control": "no-store"
  });
  res.end(typeof data === "string" ? data : JSON.stringify(data));
}

async function readJson(req) {
  let body = "";
  for await (const chunk of req) {
    body += chunk;
    if (body.length > 1_000_000) {
      throw new Error("Request body too large");
    }
  }
  return JSON.parse(body || "{}");
}

async function askAI(message) {
  if (!KEY) {
    throw new Error("OPENAI_API_KEY is not configured in the Render environment.");
  }

  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${KEY}`
    },
    body: JSON.stringify({
      model: MODEL,
      input: message
    })
  });

  const result = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(result?.error?.message || `OpenAI API request failed (${response.status})`);
  }

  const answer = (result.output || [])
    .flatMap(item => item.content || [])
    .filter(item => item.type === "output_text")
    .map(item => item.text)
    .join("\n");

  return answer || "No response text was returned by the AI.";
}

const server = http.createServer(async (req, res) => {
  try {
    if (req.method === "OPTIONS") {
      return send(res, 204, "");
    }

    const url = new URL(req.url || "/", `http://${req.headers.host || "localhost"}`);
    const pathname = url.pathname;

    if (pathname === "/api/health" && req.method === "GET") {
      return send(res, 200, {
        ok: true,
        service: "NOVA",
        aiConfigured: Boolean(KEY),
        model: MODEL
      });
    }

    if (pathname === "/api/chat" && req.method === "POST") {
      let body;
      try {
        body = await readJson(req);
      } catch (error) {
        const message = error.message === "Request body too large"
          ? "Request body too large"
          : "Invalid JSON request body";
        return send(res, 400, { ok: false, error: message });
      }

      if (typeof body.message !== "string" || !body.message.trim()) {
        return send(res, 400, { ok: false, error: "message required" });
      }

      try {
        const reply = await askAI(body.message.trim());
        return send(res, 200, { ok: true, reply });
      } catch (error) {
        return send(res, 502, {
          ok: false,
          error: error.message || "AI request failed"
        });
      }
    }

    if (req.method !== "GET" && req.method !== "HEAD") {
      return send(res, 405, { ok: false, error: "Method not allowed" });
    }

    let requestedPath;
    try {
      requestedPath = decodeURIComponent(pathname);
    } catch {
      return send(res, 400, { ok: false, error: "Invalid URL path" });
    }

    if (requestedPath === "/") {
      requestedPath = "/index.html";
    }

    const fullPath = path.resolve(ROOT, "." + requestedPath);
    if (fullPath !== ROOT && !fullPath.startsWith(ROOT + path.sep)) {
      return send(res, 403, { ok: false, error: "Forbidden" });
    }

    if (fs.existsSync(fullPath) && fs.statSync(fullPath).isFile()) {
      res.writeHead(200, {
        "Content-Type": types[path.extname(fullPath).toLowerCase()] || "application/octet-stream",
        "Access-Control-Allow-Origin": "*",
        "Cache-Control": "no-store"
      });
      return res.end(req.method === "HEAD" ? undefined : fs.readFileSync(fullPath));
    }

    return send(res, 404, { ok: false, error: "Not found" });
  } catch (error) {
    if (!res.headersSent) {
      return send(res, 500, {
        ok: false,
        error: error.message || "Internal server error"
      });
    }
    res.end();
  }
});

server.listen(PORT, HOST, () => {
  console.log(`NOVA running on ${HOST}:${PORT}`);
});
