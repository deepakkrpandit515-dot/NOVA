NOVA BACKEND FIX PACKAGE

WHAT THIS FIXES
- Serves index.html, manifest.json, sw.js and icons from the Node server.
- Adds a Backend URL setting to the frontend so a GitHub Pages website can call the deployed backend.
- Keeps chat and voice UI and the existing task/income modules.
- Adds package.json and render.yaml for Node hosting.

IMPORTANT
This ZIP does not itself make a server live. BACKEND OFFLINE appears when the frontend cannot reach a running Node backend. You must deploy this folder to a Node hosting service, then enter its HTTPS URL in NOVA using the Backend URL button (or the first prompt on GitHub Pages).

DEPLOY FROM ANDROID (NO PC)
1. Upload/replace these package files in a GitHub repository. Include package.json, render.yaml, server.js, index.html, manifest.json, sw.js, icons/ and README.txt.
2. In Render, create a new Web Service connected to that repository. The included render.yaml defines the Node start command and /api/health check. If using Blueprint deploy, review the service and create it.
3. After deployment, open the service URL and check that /api/health returns JSON with status "ok". Free hosting may sleep and take a little time to wake.
4. Open your NOVA website (GitHub Pages), tap “Backend URL” and paste the Render service HTTPS URL, e.g. https://your-service.onrender.com. This URL is only an example; use the real URL Render gives you.
5. In the hosting Environment settings, set NOVA_FRONTEND_ORIGIN to your exact GitHub Pages origin (for example https://yourname.github.io; use your real site origin, no trailing slash). Avoid leaving it as * for public use.
6. For AI chat replies, set OPENAI_API_KEY in the hosting service's Environment settings. Do not paste the key into index.html, chat, GitHub, or share it publicly. A valid provider key may involve charges.

NOTES
- The backend can report online even if no AI key is configured; chat will then return a clear configuration error.
- Do not expose an unprotected AI endpoint to the public internet: it can be abused and create API charges. Use private access controls before public use.
- This is a PWA/web app package, not a compiled APK.
